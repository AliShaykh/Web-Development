var ind=1;
function myFunction()
{
    console.log("Welcome to the game")
        // var num2=(Math.random()*9+1);
        // num2=Math.floor(num2);
        // console.log(num2);
        // // document.getElementsByTagName("h5")[0].innerHTML=num2;
        // // let value = prompt("Enter any Number ");
        // // if(value!==num2)
        // // {
        // //     ind++;
           
        // //     var image1=ind+".PNG";
        
        // //     var img=document.querySelector("img");
        // //     img.setAttribute("src",image1);
        // // }
        var num=Math.floor(Math.random()*9+1);
        console.log(num);
        var value=document.getElementsByTagName("h5")[0].innerHTML;
        var num2=prompt("Enter any number")
        if(num2!==value){
            ind++;
            var image1=ind+".PNG";
            var img=document.querySelector("img")
            img.setAttribute("src", image1);
        }

      
}